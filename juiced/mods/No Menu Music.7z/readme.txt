===================================================
No Menu Music (v1, updated 2024-08-25)
by N1GHTMAR3 (https://github.com/N1GHT-MAR3)
Juiced Modding Discord (https://discord.gg/pu2jdxR)
===================================================

Mutes the music played in the menus.

------------
Installation
------------
Extract to root of Juiced game folder.