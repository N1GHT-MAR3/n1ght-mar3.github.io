===================================================
Disable Replay Borders (v1, updated 2024-08-25)
by N1GHTMAR3 (https://github.com/N1GHT-MAR3)
Juiced Modding Discord (https://discord.gg/pu2jdxR)
===================================================

Hides the black borders at the top and bottom of the screen when viewing replays.

------------
Installation
------------
Unpacked files required. Extract to root of Juiced game folder.