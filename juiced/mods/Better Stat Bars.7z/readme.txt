===================================================
Better Stat Bars (v1, updated 2025-08-16)
by N1GHTMAR3 (https://github.com/N1GHT-MAR3)
Juiced Modding Discord (https://discord.gg/pu2jdxR)
===================================================

Re-scales the stat bars for upgrades in the Workshop to better reflect their actual efficiency.

Not compatible with any mods that modify the upgrade scripts.

------------
Installation
------------
Unpacked files required. Extract to root of Juiced game folder and overwrite when prompted.

-----------
Methodology
-----------
The three power upgrades (induction, exhaust, turbo) were all scaled based on their power mulitplier compared to the prototype turbo (the most powerful upgrade). For example, level 1 induction has a 1.02x power multiplier compared to the prototype turbo's 1.4x. Being 5% as effective, it now fills 5% of the acceleration stat bar, whereas it filled 25% before.

The other four categories use their prototype's stat bars as a base, and proportionally scales downwards based on their dataval multiplier. Since there is only the one variable that controls the effectiveness of an upgrade, the stat bars no longer show certain brands offering more of one stat versus other brands (for example, one brand's suspension upgrade being more biased towards handling versus braking, and another having more of a balance between the two) since this was never actually the case in the first place.

Stat bar comparisons between part categories (except between induction, exhaust, and turbo, those are based on BHP gain and are 100% accurate in that regard) still won't necessarily be exact. Would prototype tires really provide 70% of the braking power that prototype brakes do? Not only would testing this be a significant undertaking, but the answer to that question could vary between different cars, making it difficult or even impossible to quantify with one universal stat bar. This mod doesn't claim to make the stat bars 100% accurate - only better.
