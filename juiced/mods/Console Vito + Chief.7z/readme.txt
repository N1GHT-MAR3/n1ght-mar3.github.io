===================================================
Console Vito/Chief (v1, updated 2025-09-03)
by N1GHTMAR3 (https://github.com/N1GHT-MAR3)
Juiced Modding Discord (https://discord.gg/pu2jdxR)
===================================================

Replaces Vito and Chief's portraits with those of the console versions.

------------
Installation
------------
Unpacked files required. Extract to root of Juiced game folder and overwrite when prompted.