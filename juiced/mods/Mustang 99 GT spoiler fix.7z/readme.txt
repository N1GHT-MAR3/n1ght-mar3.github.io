===================================================
Mustang 99 GT spoiler fix (v1, updated 2025-08-15)
by N1GHTMAR3 (https://github.com/N1GHT-MAR3)
Juiced Modding Discord (https://discord.gg/pu2jdxR)
===================================================

Fixes a bug where the second and third Mustang 99 GT spoiler would swap places between the menus and in-game.

------------
Installation
------------
Unpacked files required. Extract to root of Juiced game folder and overwrite when prompted.