=============================================
Online Logon Warning (v1, updated 2024-08-23)
by N1GHTMAR3 (https://github.com/N1GHT-MAR3)
=============================================

Adds a message to the online Create Account and Logon menus warning the user that their credentials will be visible in their save file.

Will work for all languages, but is untranslated from English.

------------
Installation
------------
Unpacked files required. Extract to root of Juiced game folder.