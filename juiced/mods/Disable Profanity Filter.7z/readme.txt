===================================================
Disable Profanity Filter (v1, updated 2024-08-24)
by N1GHTMAR3 (https://github.com/N1GHT-MAR3)
Juiced Modding Discord (https://discord.gg/pu2jdxR)
===================================================

Scrambles the contents of the profanity filter to effectively disable it.

------------
Installation
------------
Unpacked files required. Extract to root of Juiced game folder.